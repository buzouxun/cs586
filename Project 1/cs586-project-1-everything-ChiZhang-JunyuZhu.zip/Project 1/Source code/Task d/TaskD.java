package task;

import java.io.IOException;
import java.util.*;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class TaskD {
	
	// <page id, name> & <page id, friend id>
	public static class Map extends Mapper<LongWritable, Text, IntWritable, Text> {
		private static IntWritable pageId = new IntWritable(-1);
		private static Text one = new Text();

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			FileSplit fileSplit = (FileSplit)context.getInputSplit();
			String filename = fileSplit.getPath().getName();			
			// mypage.txt
			if(filename.toLowerCase().contains("mypage")) {
				String line = value.toString();
				pageId = new IntWritable(Integer.valueOf(line.split(",")[0]));
				one = new Text(line.split(",")[1]);
				context.write(pageId, one);
			}			
			// friends.txt
			else if(filename.toLowerCase().contains("friends")) {
				String line = value.toString();
				pageId = new IntWritable(Integer.valueOf(line.split(",")[1]));
				one = new Text("1");
				context.write(pageId, one);
			}
		}
	} 

	// <name, number of friends>
	public static class Reduce extends Reducer<IntWritable, Text, Text, IntWritable> {

		public void reduce(IntWritable key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			Text name = new Text();
			int sum = 0;
			for(Text val : values) {
				try {
					Integer.parseInt(val.toString());
					sum += Integer.valueOf(val.toString());
				}
				catch (NumberFormatException e) {
					name = new Text(val.toString());
				}
			}
			context.write(name, new IntWritable(sum));
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		Job job = new Job(conf, "task_d");

		job.setJarByClass(task.TaskD.class);

		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(Map.class);
		job.setReducerClass(Reduce.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileInputFormat.addInputPath(job, new Path(args[1]));
		FileOutputFormat.setOutputPath(job, new Path(args[2]));

		job.waitForCompletion(true);
	}

}
