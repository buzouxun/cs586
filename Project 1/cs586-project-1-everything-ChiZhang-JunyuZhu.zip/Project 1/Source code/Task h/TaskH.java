package task;


import java.io.IOException;
import java.util.*;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class TaskH {

	// person A and person B. A and B are friends. A and B access each other's page at almost same time
	private static int sameTime = 10657;

	// <page id + friend id, friend> & <page id + friend id, access time>
	public static class Map extends Mapper<LongWritable, Text, Text, Text> {
		private static Text personAndFriend = new Text();
		private static Text relationship = new Text();

		public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			FileSplit fileSplit = (FileSplit)context.getInputSplit();
			String filename = fileSplit.getPath().getName();			
			// friends.txt
			if(filename.toLowerCase().contains("friends")) {
				String line = value.toString();
				personAndFriend = new Text(makeMapKey(Integer.valueOf(line.split(",")[1]), Integer.valueOf(line.split(",")[2])));
				relationship = new Text("friend");
				context.write(personAndFriend, relationship);
			}			
			// accesslog.txt
			else if(filename.toLowerCase().contains("accesslog")) {
				String line = value.toString();
				personAndFriend = new Text(makeMapKey(Integer.valueOf(line.split(",")[1]), Integer.valueOf(line.split(",")[2])));
				relationship = new Text(makeMapValue(Integer.valueOf(line.split(",")[1]), Integer.valueOf(line.split(",")[2]), 
						Integer.valueOf(line.split(",")[4])));
				context.write(personAndFriend, relationship);
			}
		}
	} 

	// <person id + friend id, two timestamps of access>
	public static class Reduce extends Reducer<Text, Text, Text, Text> {

		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			boolean friend = false;
			boolean less = false;
			boolean more = false;
			List<Integer> lessArray = new ArrayList<Integer>();
			List<Integer> moreArray = new ArrayList<Integer>();
			int[] lessSameTime = new int[1];
			int[] moreSameTime = new int[1];

			for(Text val : values) {
				if(val.toString().equals("friend")) {
					friend = true;
				}
				else {
					if(val.toString().contains("LESS")) {
						less = true;
						lessArray.add(Integer.valueOf(val.toString().split("\\+")[0]));
					}
					else if(val.toString().contains("MORE")) {
						more = true;
						moreArray.add(Integer.valueOf(val.toString().split("\\+")[0]));
					}
				}
			}
			if(friend && less && more && accessSameTime(lessArray, moreArray, sameTime, lessSameTime, moreSameTime)) {
				context.write(key, new Text(String.valueOf(lessSameTime[0]) + "+" + String.valueOf(moreSameTime[0])));
			}
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		Job job = new Job(conf, "task_h");

		job.setJarByClass(task.TaskH.class);

		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(Map.class);
		job.setReducerClass(Reduce.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileInputFormat.addInputPath(job, new Path(args[1]));
		FileOutputFormat.setOutputPath(job, new Path(args[2]));

		job.waitForCompletion(true);
	}

	/**
	 * Helper function to make key in mapper
	 * 
	 * @param id1
	 * @param id2
	 * @return
	 */
	private static String makeMapKey(int id1, int id2) {
		String newKey = "";
		if(id1 < id2) {
			newKey = String.valueOf(id1) + "+" + String.valueOf(id2);
		}
		else {
			newKey = String.valueOf(id2) + "+" + String.valueOf(id1);
		}
		return newKey;
	}

	/**
	 * Helper function to make value in mapper
	 *
	 * @param id1
	 * @param id2
	 * @param accessTime
	 * @return
	 */
	private static String makeMapValue(int id1, int id2, int accessTime) {
		String newKey = "";
		if(id1 < id2) {
			newKey = String.valueOf(accessTime) + "+" + "LESS";
		}
		else {
			newKey = String.valueOf(accessTime) + "+" + "MORE";
		}
		return newKey;
	}

	/**
	 * Helper function to determine if person A and person B access each others'
	 * page at the same time
	 * 
	 * @param a_b
	 * @param b_a
	 * @param moreSameTime 
	 * @param lessSameTime 
	 * @param sameTime2
	 * @return
	 */
	public static boolean accessSameTime(List<Integer> a_b, List<Integer> b_a, int sameTimeDiff, int[] lessSameTime, int[] moreSameTime) {
		boolean sameTime = false;
		for(int i : a_b) {
			for(int j : b_a) {
				if(Math.abs( ((long)j) - ((long)i)) < ((long)sameTimeDiff)) {
					sameTime = true;
					lessSameTime[0] = i;
					moreSameTime[0] = j;
				}
			}
		}
		return sameTime;
	}

}
