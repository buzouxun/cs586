package mypackage;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.FileInputFormat;
import org.apache.hadoop.mapred.FileOutputFormat;
import org.apache.hadoop.mapred.JobClient;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapred.MapReduceBase;
import org.apache.hadoop.mapred.Mapper;
import org.apache.hadoop.mapred.OutputCollector;
import org.apache.hadoop.mapred.Reducer;
import org.apache.hadoop.mapred.Reporter;
import org.apache.hadoop.mapred.TextInputFormat;
import org.apache.hadoop.mapred.TextOutputFormat;

public class query5 {
	public static class Map extends MapReduceBase implements
	Mapper<LongWritable, Text, IntWritable, IntWritable> {
		private IntWritable outputKey;
		private IntWritable outputValue;
		@Override
		public void map(LongWritable key, Text value,
				OutputCollector<IntWritable, IntWritable> output, Reporter reportor)
						throws IOException {
			String line = value.toString();
			String[] tokens = line.split(",");//AccessId, ByWho, WhatPage, TypeOfAccess, AccessTime
			int byWho = Integer.valueOf(tokens[1]);// 1 = ByWho
			int whatPage = Integer.valueOf(tokens[2]);// 2 = WhatPage
			outputKey = new IntWritable(byWho);
			outputValue = new IntWritable(whatPage);
			output.collect(outputKey, outputValue);
		}
	}
	
	public static class Reduce extends MapReduceBase implements 
	Reducer<IntWritable, IntWritable, IntWritable, Text> {

		@Override
		public void reduce(IntWritable keyByWho, Iterator<IntWritable> valuesWhatPage,
				OutputCollector<IntWritable, Text> output, Reporter reporter) throws IOException {
			int sumTotal = 0;
			int sumDistinct = 0;
			HashMap<Integer, Boolean> checked = new  HashMap<Integer, Boolean>();
			int temp;
			while (valuesWhatPage.hasNext()) {
				sumTotal ++;
				temp = valuesWhatPage.next().get();
				if(!checked.containsKey(temp)){ //disctinct
					checked.put(temp, true);
					sumDistinct++;
				}	
			}
			String result = "Totally viewed "+ sumTotal +" pages, and " + sumDistinct + " different pages";
			output.collect(keyByWho,new Text(result));
		}
		
	}
	

	public static void main(String[] args) throws Exception{
		JobConf conf = new JobConf(query5.class);
		conf.setJobName("Task 5");
		
		
		
		conf.setMapperClass(Map.class);
		conf.setMapOutputKeyClass(IntWritable.class);//change mapper output class
		conf.setMapOutputValueClass(IntWritable.class);
		//conf.setCombinerClass(Reduce.class);
		conf.setReducerClass(Reduce.class);
		
		//conf.setInputFormat(TextInputFormat.class);
		//conf.setOutputFormat(TextOutputFormat.class);

		FileInputFormat.addInputPath(conf, new Path(args[0]));
		FileOutputFormat.setOutputPath(conf, new Path(args[1]));

		JobClient.runJob(conf);

	}

}
