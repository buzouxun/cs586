package mypackage;

import java.io.IOException;
import java.util.*;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapred.*;
import org.apache.hadoop.util.*;

public class query7 {
	public static class Map extends MapReduceBase implements Mapper<LongWritable, Text, Text, Text> {
        private Text bywho = new Text();
        
        public void map (LongWritable key, Text value, OutputCollector<Text,Text> output, Reporter reporter) throws IOException {
            String line = value.toString();
            String[] splits = line.split(",");
            bywho.set(splits[1]);
            output.collect(bywho, new Text(splits[4]));                 
        }
    }
  
    
    public static class Reduce extends MapReduceBase implements Reducer<Text, Text, Text, Text> {
        public void reduce (Text key, Iterator<Text> values, OutputCollector<Text, Text> output, Reporter reporter) throws IOException {
            int createtime = 800000;    
            int lasttime;

            while (values.hasNext()) {
                lasttime = Integer.parseInt(values.next().toString());
                if (lasttime <= createtime)
                    continue;
                else
                    return;
            }
            output.collect(key, new Text()); 
        }
    }

      public static void main(String[] args) throws Exception {
          JobConf conf = new JobConf(query7.class);
          conf.setJobName("Task7");
  
          conf.setOutputKeyClass(Text.class);
          conf.setOutputValueClass(Text.class);
  
          conf.setMapperClass(Map.class);
          conf.setReducerClass(Reduce.class);
  
          conf.setInputFormat(TextInputFormat.class);
          conf.setOutputFormat(TextOutputFormat.class);
  
          FileInputFormat.setInputPaths(conf, new Path(args[0]));
          FileOutputFormat.setOutputPath(conf, new Path(args[1]));
  
          JobClient.runJob(conf);
      }
}
